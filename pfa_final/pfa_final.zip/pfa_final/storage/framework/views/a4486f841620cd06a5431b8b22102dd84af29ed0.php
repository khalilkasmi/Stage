<div class="card">
    <div class="card-header">
       <div class="card-title"> Thank you <3</div>
        <span class="text-green">your reservation has been confirmed</span>
    </div>
    <div class="card-body">
        <h3 class="text-center">Reservation Details</h3>
        <div class="row">
            <h6>Delivery place : <?php echo e($reservation->city); ?></h6>
            <h6>car : </h6>
            <p>
                <?php echo e(\App\models\brand::find(\App\models\car::find($reservation->car_id)->brand_id)->brand_name); ?>

                /
                <?php echo e(\App\models\CarModel::find(\App\models\car::find($reservation->car_id)->model_id)->car_model_name); ?>

            </p>
            <h6> start date : <?php echo e($reservation->start_date); ?> </h6>
            <h6> end date : <?php echo e($reservation->end_date); ?> </h6>
            <h1>price to pay : <?php echo e($reservation->total_to_pay); ?></h1>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/emails/carReserved.blade.php ENDPATH**/ ?>