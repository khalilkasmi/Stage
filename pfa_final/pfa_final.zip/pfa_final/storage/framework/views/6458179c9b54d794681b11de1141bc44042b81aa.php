






    <div class="container">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header text-center">

                        make a search

                    </div>
                    <div class="card-body">

                        <form action="search" method="GET">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-12">

                                    <div class="input-group mb-3">
                                        <input type="text" name="search_city" class="form-control <?php if ($errors->has('search_city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('search_city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="search by city" aria-label="search by city" >
                                        <div class="input-group-append">
                                        </div>
                                        <?php if ($errors->has('search_city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('search_city'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-6">
                                    <label for="start_date">Start Date</label>
                                    <div class="input-group mb-3">
                                        <input type="date" id="start_date" name="start_date" class="form-control <?php if ($errors->has('start_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" >
                                        <div class="input-group-append">
                                        </div>
                                        <?php if ($errors->has('start_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_date'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <label for="end_date">End Date</label>
                                    <div class="input-group mb-3">

                                        <input type="date" class="form-control <?php if ($errors->has('end_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="end_date" id="end_date" >
                                        <div class="input-group-append">
                                        </div>
                                        <?php if ($errors->has('end_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_date'); ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4"></div>
                                <div class="col-4">
                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Search')); ?>

                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-4"></div>
                            </div>


                        </form>

                    </div>
                </div>
            </div>
            <div class="col-2"></div>
        </div>
        <br>
        <?php if(\Illuminate\Support\Facades\Auth::user() != null): ?>
            <div class="row">
                <div class="col-2"></div>
                <div class="col-8">
                    <div class="card">
                        <div class="card-header">
                            My Reservations
                        </div>
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">


                                        <table class="table table-striped">
                                            <thead>
                                            <tr>
                                                <th scope="col">city</th>
                                                <th scope="col">Car</th>
                                                <th scope="col">Start Date</th>
                                                <th scope="col">End Date</th>
                                                <th scope="col"></th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->client->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($res->confirmed == 0): ?>
                                                    <tr class="table-active">
                                                        <th scope="col"><?php echo e($res->city); ?></th>
                                                        <th scope="col">

                                                            <a href="<?php echo e(route('cars.show',[$res->car_id])); ?>">

                                                                <?php echo e(\App\models\brand::find(\App\models\car::find($res->car_id)->brand_id)->brand_name); ?>

                                                                ,
                                                                <?php echo e(\App\models\CarModel::find(\App\models\car::find($res->car_id)->model_id)->car_model_name); ?>


                                                            </a>

                                                        </th>
                                                        <th scope="col">
                                                            <?php echo e($res->start_date); ?>

                                                        </th>
                                                        <th scope="col">

                                                            <?php echo e($res->end_date); ?>


                                                        </th>
                                                        <th scope="col">
                                                            <?php echo Form::open(['method'=>'DELETE','route'=>['reservations.destroy',$res->id]]); ?>

                                                            <?php echo Form::submit('Cancel',['class'=>'btn btn-danger float-right']); ?>

                                                            <?php echo Form::close(); ?>

                                                        </th>
                                                    </tr>

                                                <?php else: ?>
                                                    <tr class="table-success">
                                                        <th scope="col" ><?php echo e($res->city); ?></th>
                                                        <th scope="col">

                                                            <a href="<?php echo e(route('cars.show',[$res->car_id])); ?>">

                                                                <?php echo e(\App\models\brand::find(\App\models\car::find($res->car_id)->brand_id)->brand_name); ?>

                                                                ,
                                                                <?php echo e(\App\models\CarModel::find(\App\models\car::find($res->car_id)->model_id)->car_model_name); ?>


                                                            </a>

                                                        </th>
                                                        <th scope="col">
                                                            <?php echo e($res->start_date); ?>

                                                        </th>
                                                        <th scope="col">

                                                            <?php echo e($res->end_date); ?>


                                                        </th>
                                                        <th scope="col">
                                                            <?php echo Form::open(['method'=>'DELETE','route'=>['reservations.destroy',$res->id]]); ?>

                                                            <?php echo Form::submit('Cancel',['class'=>'btn btn-danger float-right']); ?>

                                                            <?php echo Form::close(); ?>

                                                        </th>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>





<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/client_geust.blade.php ENDPATH**/ ?>