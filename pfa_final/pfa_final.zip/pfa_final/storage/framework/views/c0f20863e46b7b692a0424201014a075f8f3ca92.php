<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="card">
                    <div class="card-header text-center">

                        make a search

                    </div>
                    <div class="card-body">

                        <form action="search" method="GET">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-12">

                                <div class="input-group mb-3">
                                    <input type="text" name="search_city" class="form-control <?php if ($errors->has('search_city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('search_city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="search by city" aria-label="search by city" >
                                    <div class="input-group-append">
                                    </div>
                                    <?php if ($errors->has('search_city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('search_city'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>

                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <label for="start_date">Start Date</label>
                                <div class="input-group mb-3">
                                    <input type="date" id="start_date" name="start_date" class="form-control <?php if ($errors->has('start_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" >
                                    <div class="input-group-append">
                                    </div>
                                    <?php if ($errors->has('start_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_date'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="col-6">
                                <label for="end_date">End Date</label>
                                <div class="input-group mb-3">

                                    <input type="date" class="form-control <?php if ($errors->has('end_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="end_date" id="end_date" >
                                    <div class="input-group-append">
                                    </div>
                                    <?php if ($errors->has('end_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_date'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4"></div>
                            <div class="col-4">
                                <div class="form-group row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                        <button type="submit" class="btn btn-primary">
                                            <?php echo e(__('Search')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4"></div>
                        </div>


                        </form>

                    </div>
                </div>
            </div>
            <div class="col-2"></div>
        </div>
        <br>
       <?php if(\Illuminate\Support\Facades\Auth::user() != null): ?>
            <div class="row">
    <h1>My Reservations</h1>

                            <div class="container">
                               <div class="row">
                                   <div class="card-columns">
                                       <?php $__currentLoopData = \Illuminate\Support\Facades\Auth::user()->client->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                           <div class="card" style="padding: .5em;box-shadow: 1px 6px 20px 0px #9a9c9b54;">
                                               <img src="<?php echo e(\App\models\car::find($res->car_id)->image); ?>" class="card-img-top" >
                                               <div class="card-body">
                                                   <div class="row">
                                                       <div class="col-3">
                                                           <img src="<?php echo e(\App\models\Agence::find($res->agence_id)->entreprise->logo_path); ?>" alt="<?php echo e(\App\models\Agence::find($res->agence_id)->entreprise->logo_path); ?>" width="50px" height="50px">
                                                       </div>
                                                       <div class="col-9">
                                                           <div class="row">
                                                               <div class="col-12 card-title"><strong>
                                                                       <?php echo e(\App\models\brand::find(\App\models\car::find($res->car_id)->brand_id)->brand_name); ?>/
                                                                       <?php echo e(\App\models\CarModel::find(\App\models\car::find($res->car_id)->model_id)->car_model_name); ?> -
                                                                       <?php echo e(\App\models\CarModel::find(\App\models\car::find($res->car_id)->model_id)->car_model_year); ?>

                                                                   </strong></div>
                                                               <div class="row">
                                                                   <div class="col-12 card-subtitle text-muted">&nbsp;&nbsp;&nbsp;<?php echo e(\App\models\car::find($res->car_id)->type); ?></div>
                                                               </div>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>
                                               <div class="card-text">
                                                   <div class="row">
                                                       <div class="col-12">
                                                           <h6>delivery place :
                                                               <a href="https://maps.google.com/?q=<?php echo e(\App\models\car::find($res->car_id)->delivery_place); ?>"><?php echo e(\App\models\car::find($res->car_id)->delivery_place); ?></a>
                                                           </h6>
                                                           <p>
                                                               starts on : <?php echo e($res->start_date); ?>

                                                               ends on : <?php echo e($res->end_date); ?> <br>
                                                               price :
                                                               <span class="btn btn-outline-primary"><?php echo e(\App\models\car::find($res->car_id)->price); ?> <strong><small>DH</small></strong>/<small>day</small></span><br>
                                                               Total to pay :
                                                               <span class="btn btn-outline-danger"><?php echo e($res->total_to_pay); ?> <strong>DH</strong></span>
                                                           </p>
                                                           <p>
                                                               <span class="badge badge-pill badge-primary"><?php echo e(\App\models\car::find($res->car_id)->transmission); ?></span>
                                                               <span class="badge badge-pill badge-success">
									<?php echo e(\App\models\car::find($res->car_id)->fuel); ?>

                                                                   <?php if(\App\models\car::find($res->car_id)->fuel_policy == 'yes'): ?>
                                                                       (full)
                                                                   <?php endif; ?>
									</span>
                                                               <?php if(\App\models\car::find($res->car_id)->mileage_unlimited == 1): ?>
                                                                   <span class="badge badge-pill badge-info">unlimited mileage</span>
                                                               <?php endif; ?>
                                                               <span class="badge badge-pill badge-dark"><?php echo e(\App\models\car::find($res->car_id)->seats); ?> seats</span>
                                                               <span class="badge badge-pill badge-light"><?php echo e(\App\models\car::find($res->car_id)->luggage); ?> luggages</span>

                                                           </p>

                                                           <?php if($res->confirmed == 0): ?>
                                                               <span class="btn btn-outline-warning">pending ...</span>
                                                           <?php else: ?>
                                                               <span class="btn btn-outline-success">Confirmed</span>
                                                           <?php endif; ?>


                                                           <?php echo Form::open(['method'=>'DELETE','route'=>['reservations.destroy',$res->id]]); ?>

                                                           <?php echo Form::submit('Cancel',['class'=>'btn btn-danger float-right']); ?>

                                                           <?php echo Form::close(); ?>

                                                       </div>

                                                   </div>
                                               </div>
                                           </div>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                               </div>
                            </div>
                        </div>
                    </div>

        <?php endif; ?>
    </div>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/car_search.blade.php ENDPATH**/ ?>