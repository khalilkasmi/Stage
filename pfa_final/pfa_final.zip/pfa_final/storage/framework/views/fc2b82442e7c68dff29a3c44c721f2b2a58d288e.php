<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">

            <h3>My cars</h3>
            <div class="row">
                <div class="col-6"></div>
                <div class="col-6">
                    <a href="/agences/<?php echo e($agency->id); ?>/cars/add" class="btn btn-primary float-right">add a car </a>
                </div>
            </div>

            <div class="container">
                <div class="card-columns">
                    <?php $__currentLoopData = $agency->cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" style="padding: .5em;box-shadow: 1px 6px 20px 0px #9a9c9b54;">
                            <img src="<?php echo e($car->image); ?>"  alt="<?php echo e($car->image); ?>" class="card-img-top" >
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-2">
                                        <img src="\<?php echo e(\App\models\Agence::find($car->agence_id)->entreprise->logo_path); ?>" alt="logo" width="50px" height="50px">
                                    </div>
                                    <div class="col-8">
                                        <div class="row">
                                            <div class="col-12 card-title"><strong>
                                                    <?php echo e(\App\models\brand::find($car->brand_id)->brand_name); ?>/
                                                    <?php echo e(\App\models\CarModel::find($car->model_id)->car_model_name); ?> -
                                                    <?php echo e(\App\models\CarModel::find($car->model_id)->car_model_year); ?>

                                                </strong></div>
                                            <div class="row">
                                                <div class="col-12 card-subtitle text-muted"><?php echo e($car->type); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-text">
                                <div class="row">
                                    <div class="col-12">
                                        <h6>delivery place :
                                            <a href="https://maps.google.com/?q=<?php echo e($car->delivery_place); ?>"><?php echo e($car->delivery_place); ?></a>
                                        </h6>
                                        <p>
                                            avialable on : <?php echo e($car->aviability_date); ?>

                                        </p>
                                        <p>
                                            <span class="badge badge-pill badge-primary"><?php echo e($car->transmission); ?></span>
                                            <span class="badge badge-pill badge-success">
									<?php echo e($car->fuel); ?>

                                                <?php if($car->fuel_policy == 'yes'): ?>
                                                    (full)
                                                <?php endif; ?>
									</span>
                                            <?php if($car->mileage_unlimited == 1): ?>
                                                <span class="badge badge-pill badge-info">unlimited mileage</span>
                                            <?php endif; ?>
                                            <span class="badge badge-pill badge-dark"><?php echo e($car->seats); ?> seats</span>
                                            <span class="badge badge-pill badge-light"><?php echo e($car->luggage); ?> luggages</span>

                                        </p>


                                        <?php echo Form::open(['method'=>'DELETE','route'=>['cars.destroy',$car->id]]); ?>

                                        <?php echo Form::submit('Delete',['class'=>'btn btn-primary float-right']); ?>

                                        <?php echo Form::close(); ?>


                                        <?php echo link_to_route('cars.edit','update',[$car->id],['class'=>'btn btn-warning float-right']); ?>



                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/cars/cars_list.blade.php ENDPATH**/ ?>