<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row">
            <div class="col-12">



            <?php if(\Session::has('success')): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?php echo \Session::get('success'); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <!-- ******************************************************* -->

            <div class="col-120">
            <h1>Results</h1>
                <div class="card-columns">



                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $__currentLoopData = $result->cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if(\Carbon\Carbon::parse($car->aviability_date)->isBefore(\Carbon\Carbon::parse($start))): ?>


                                <div class="card" style="padding: .5em;box-shadow: 1px 6px 20px 0px #9a9c9b54;">
                                    <img src="<?php echo e($car->image); ?>" class="card-img-top" >
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-3">
                                                <img src="<?php echo e($result->entreprise->logo_path); ?>" alt="<?php echo e($result->entreprise->logo_path); ?>" width="50px" height="50px">
                                            </div>
                                            <div class="col-9">
                                                <div class="row">
                                                    <div class="col-12 card-title"><strong>
                                                            <?php echo e(\App\models\brand::find($car->brand_id)->brand_name); ?>/
                                                            <?php echo e(\App\models\CarModel::find($car->model_id)->car_model_name); ?> -
                                                            <?php echo e(\App\models\CarModel::find($car->model_id)->car_model_year); ?>

                                                        </strong></div>
                                                    <div class="row">
                                                        <div class="col-12 card-subtitle text-muted">&nbsp;&nbsp;&nbsp;<?php echo e($car->type); ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-text">
                                        <div class="row">
                                            <div class="col-12">
                                                <h6>delivery place :
                                                    <a href="https://maps.google.com/?q=<?php echo e($car->delivery_place); ?>"><?php echo e($car->delivery_place); ?></a>
                                                </h6>
                                                <p>
                                                    avialable on : <?php echo e($car->aviability_date); ?>

                                                </p>
                                                <p>
                                                    <span class="badge badge-pill badge-primary"><?php echo e($car->transmission); ?></span>
                                                    <span class="badge badge-pill badge-success">
									<?php echo e($car->fuel); ?>

                                                        <?php if($car->fuel_policy == 'yes'): ?>
                                                            (full)
                                                        <?php endif; ?>
									</span>
                                                    <?php if($car->mileage_unlimited == 1): ?>
                                                        <span class="badge badge-pill badge-info">unlimited mileage</span>
                                                    <?php endif; ?>
                                                    <span class="badge badge-pill badge-dark"><?php echo e($car->seats); ?> seats</span>
                                                    <span class="badge badge-pill badge-light"><?php echo e($car->luggage); ?> luggages</span>

                                                </p>


                                                <?php if(\Illuminate\Support\Facades\Auth::user() != null): ?>
                                                    <?php echo Form::open(['method'=>'POST','action'=>'ReservationsController@store']); ?>

                                                    <?php echo e(Form::hidden('start', $start)); ?>

                                                    <?php echo e(Form::hidden('end', $end)); ?>

                                                    <?php echo e(Form::hidden('car_id', $car->id)); ?>

                                                    <?php echo e(Form::hidden('user_id',\Illuminate\Support\Facades\Auth::user()->id)); ?>

                                                    <button type="submit" class="btn btn-outline-info float-right">Rent <?php echo e($car->price); ?> <strong>DH</strong>/<small><strong>day</strong></small></button>
                                                    <?php echo Form::close(); ?>

                                                <?php else: ?>
                                                    <a href="/login" target="_blank" class="btn btn-outline-info float-right"><?php echo e($car->price); ?>

                                                        <strong>DH</strong>/<small><strong>day</strong></small></a>

                                                <?php endif; ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-6"></div>
                                    <div class="col-6"><h1>no cars found</h1></div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            <!-- ******************************************************* -->
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/car_search_list.blade.php ENDPATH**/ ?>