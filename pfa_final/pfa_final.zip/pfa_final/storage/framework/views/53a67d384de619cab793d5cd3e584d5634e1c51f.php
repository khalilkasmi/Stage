<?php if(!Auth::user()->client): ?>
    <?php echo $__env->make('Client.client_registration_completion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>

    <?php echo $__env->make('Client.car_search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php endif; ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/client_home.blade.php ENDPATH**/ ?>