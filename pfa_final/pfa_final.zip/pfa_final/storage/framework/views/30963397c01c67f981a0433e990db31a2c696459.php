<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1>My Reservations</h1>
        <div class="row">
            <div class="col-2"></div>
            <div class="card-columns">
                <?php $__currentLoopData = $agency->reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="card" style="width: 18rem;">


                <div class="card-body">
                    <h5 class="card-title">
                        <a href="<?php echo e(route('clients.show',[$reservation->client_id])); ?>">

                            <?php echo e(\App\models\client::find($reservation->client_id)->first_name); ?>

                            ,
                            <?php echo e(\App\models\client::find($reservation->client_id)->last_name); ?>


                        </a>
                    </h5>
                    <h6 class="card-subtitle mb-2 text-muted">
                        <a href="<?php echo e(route('cars.show',[$reservation->car_id])); ?>">

                            <?php echo e(\App\models\brand::find(\App\models\car::find($reservation->car_id)->brand_id)->brand_name); ?>

                            /
                            <?php echo e(\App\models\CarModel::find(\App\models\car::find($reservation->car_id)->model_id)->car_model_name); ?>


                        </a>
                    </h6>
                        <?php if(\Carbon\Carbon::parse($reservation->start_date)->diffInDays(\Carbon\Carbon::parse(now())) < 1): ?>
                        <p class="card-text" style="color:red;">
                        <?php else: ?>
                        <p class="card-text">
                        <?php endif; ?>
                            start date : <?php echo e($reservation->start_date); ?> <br>
                            end date : <?php echo e($reservation->end_date); ?> <br>
                        city : <a href="https://www.google.com/maps?q="<?php echo e($reservation->city); ?>><?php echo e($reservation->city); ?></a>
                    </p>
                    <div  class="card-link">
                        <?php echo Form::open(['method'=>'DELETE','route'=>['reservations.destroy',$reservation->id]]); ?>

                        <?php echo Form::submit('Delete',['class'=>'btn btn-primary float-right']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                    <?php if(\Carbon\Carbon::parse($reservation->start_date)->diffInDays(\Carbon\Carbon::parse(now())) > 1): ?>
                            <?php if($reservation->confirmed == 0): ?>
                                <div  class="card-link"><?php echo link_to_route('reservations.edit','confimer',[$reservation->id],['class'=>'btn btn-warning float-right']); ?></div>
<?php endif; ?>
                            <?php endif; ?>
                </div>
            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Agence/agency_reservations.blade.php ENDPATH**/ ?>