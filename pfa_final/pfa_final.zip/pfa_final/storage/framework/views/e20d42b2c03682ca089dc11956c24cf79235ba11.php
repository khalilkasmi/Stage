 

 <?php $__env->startSection('content'); ?>


     <div class="container">
         <div class="row">
             <div class="col-3"></div>
             <div class="col-6">
                 <div class="card">

                     <div class="card-header">Update Agency</div>

                     <div class="card-body">


                         <?php echo Form::open(['method'=>'PUT','route'=>['agences.update',$agency->id]]); ?>


                         <?php echo csrf_field(); ?>

                         <div class="form-group row">
                             <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's City")); ?></label>

                             <div class="col-md-6">
                                 <input id="city" type="text" class="form-control <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="city" value="<?php echo e($agency->city); ?>" placeholder="<?php echo e($agency->city); ?>" required autocomplete="Agency's city" autofocus>

                                 <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
                                 <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                             </div>
                         </div>


                         <div class="form-group row">
                             <label for="adress" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's Adress")); ?></label>

                             <div class="col-md-6">
                                 <input id="adress" type="textarea" class="form-control <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="adress" value="<?php echo e($agency->adress); ?>" placeholder="<?php echo e($agency->adress); ?>" required autocomplete="Agency's adress" autofocus>

                                 <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?>
                                 <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                             </div>
                         </div>

                         <div class="form-group row">
                             <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's Phone")); ?></label>

                             <div class="col-md-6">
                                 <input id="phone" type="phone" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" value="<?php echo e($agency->phone); ?>" placeholder="<?php echo e($agency->phone); ?>" required autocomplete="Agency's phone" autofocus>

                                 <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                 <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                 <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                             </div>
                         </div>

                         <input type="hidden" value="<?php echo e(Auth::user()->entreprise->id); ?>" name="enterprise_id">


                         <div class="row">
                             <div class="col-12">
                                 <?php echo Form::submit('Update',['class'=>'btn btn-primary float-right']); ?>

                             </div>
                         </div>

                         <?php echo Form::close(); ?>


                     </div>
                 </div>
             </div>
         </div>
     </div>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Agence/agency_update.blade.php ENDPATH**/ ?>