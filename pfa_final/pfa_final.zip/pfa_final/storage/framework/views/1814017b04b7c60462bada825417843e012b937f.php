    <ul class="list-group">
        <?php $__currentLoopData = \App\models\Entreprise::find(Auth::user()->entreprise->id)->agences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="list-group-item"><?php echo e($agence->city); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Agence/agencies_list.blade.php ENDPATH**/ ?>