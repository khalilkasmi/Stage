<?php if(!Auth::user()->entreprise): ?>
    <?php echo $__env->make('Entreprise.enterprise_registration_completion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php if(sizeof(\App\models\Entreprise::find(Auth::user()->entreprise->id)->agences) == 0): ?>
        <h3>Add Agency</h3>
        <?php echo $__env->make('Agence.agency_add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('Agence.agencies_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Entreprise/entreprise_home.blade.php ENDPATH**/ ?>