        <h3>My Agencies</h3>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">city</th>
                <th scope="col">adress</th>
                <th scope="col">phone</th>
                <th scope="col">cars</th>
                <th scope="col">Reservations</th>
                <th scope="col"></th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
<?php $__currentLoopData = \App\models\Entreprise::find(Auth::user()->entreprise->id)->agences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr>
                    <th scope="row"><?php echo e($agence->city); ?></th>
                    <td><?php echo e($agence->adress); ?></td>
                    <td><?php echo e($agence->phone); ?></td>
                    <td>

                        <a href="<?php echo e(route('agences.show',$agence->id)); ?>">
                            <span class="btn btn-primary">
                                <?php echo e($agence->cars->count()); ?>

                            </span>
                        </a>

                    </td>

                    <td>

                        <a href="<?php echo e(route('reservations.show',$agence->id)); ?>">
                            <span class="btn btn-danger">
                                <?php echo e($agence->reservations->count()); ?>

                            </span>
                        </a>

                    </td>
                    <td>

                        <?php echo Form::open(['method'=>'DELETE','route'=>['agences.destroy',$agence->id]]); ?>

                        <?php echo Form::submit('Delete',['class'=>'btn btn-primary float-right']); ?>

                        <?php echo Form::close(); ?>


                    </td>
                    <td>

                        <?php echo link_to_route('agences.edit','update',[$agence->id],['class'=>'btn btn-warning float-right']); ?>



                    </td>
                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

    <div class="row"><div class="col-6"><br></div></div>
    <div class="row">
            <div class="col-6">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">

                    Add Agency
                </button>
            </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Agency</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo $__env->make('Agence.agency_add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>




    </div>
<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Agence/agencies_list.blade.php ENDPATH**/ ?>