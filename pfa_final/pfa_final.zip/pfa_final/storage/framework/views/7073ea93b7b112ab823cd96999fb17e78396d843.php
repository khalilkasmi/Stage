
                <div class="card-header"><?php echo e(__('Continue Registration')); ?></div>

                <div class="card-body">

                        <form method="POST" action="entreprises" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="company_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Company Name')); ?></label>

                            <div class="col-md-6">
                                <input id="company_name" type="text" class="form-control <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="company_name" value="<?php echo e(old('Company Name')); ?>" required autocomplete="Company Name" autofocus>

                                <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="land_line" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Land line')); ?></label>

                            <div class="col-md-6">
                                <input id="land_line" type="phone" class="form-control <?php if ($errors->has('land_line')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('land_line'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="land_line" value="<?php echo e(old('Land line')); ?>" required autocomplete="land line">

                                <?php if ($errors->has('land_line')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('land_line'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                            <div class="col-md-6">
                                <input id="description" type="textarea" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="description" required >

                                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>


                            <div class="form-group row">
                                <label for="adress" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Adress')); ?></label>

                                <div class="col-md-6">
                                    <input id="adress" type="textarea" class="form-control <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="adress" required >

                                    <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Logo</label>
                                <input type="file" name="logo_path" class="form-control <?php if ($errors->has('logo_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('logo_path'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><br>
                                <?php if ($errors->has('logo_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('logo_path'); ?>
                                <span class="invalid-feedback " role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>

                            <div class="form-group">
                                <label>Extra Docs</label>
                                <input type="file" name="extra_docs" class="form-control <?php if ($errors->has('extra_docs')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('extra_docs'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" accept=".zip,.rar,.7zip"><br>
                                <?php if ($errors->has('extra_docs')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('extra_docs'); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>








                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>

<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Entreprise/enterprise_registration_completion.blade.php ENDPATH**/ ?>