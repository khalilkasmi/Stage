<?php $__env->startSection('content'); ?>


                <?php echo $__env->make('Client.car_search_list',['results'=>$results], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/car_search_result.blade.php ENDPATH**/ ?>