<p>Hi <?php echo e($data['name']); ?>,</p>
<p>thans to contact us about (<?php echo e($data['subject']); ?>),</p>
<p>The message is: <br> <?php echo e($data['message']); ?></p>
<p>Cordialement.</p><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/emails/email_template_contact.blade.php ENDPATH**/ ?>