<div class="row">
    <div class="col-12">
        <div class="card">

            <div class="card-body">

                <form action="agences" method="POST">

                    <?php echo csrf_field(); ?>

                    <div class="form-group row">
                        <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's City")); ?></label>

                        <div class="col-md-6">
                            <input id="city" type="text" class="form-control <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="city" value="<?php echo e(old("Agency's city")); ?>" required autocomplete="Agency's city" autofocus>

                            <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="adress" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's Adress")); ?></label>

                        <div class="col-md-6">
                            <input id="adress" type="textarea" class="form-control <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="adress" value="<?php echo e(old("Agency's adress")); ?>" required autocomplete="Agency's adress" autofocus>

                            <?php if ($errors->has('adress')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('adress'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="phone" class="col-md-4 col-form-label text-md-right"><?php echo e(__("Agency's Phone")); ?></label>

                        <div class="col-md-6">
                            <input id="phone" type="phone" class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="phone" value="<?php echo e(old("Agency's phone")); ?>" required autocomplete="Agency's phone" autofocus>

                            <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>

                    <input type="hidden" value="<?php echo e(Auth::user()->entreprise->id); ?>" name="enterprise_id">


                    <div class="form-group row mb-0">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add')); ?>

                            </button>
                        </div>
                    </div>


                </form>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Agence/agency_add.blade.php ENDPATH**/ ?>