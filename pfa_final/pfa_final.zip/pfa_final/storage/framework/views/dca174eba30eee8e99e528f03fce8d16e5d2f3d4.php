<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">Mes Reservation</div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th scope="col">Profile Picture</th>
                                <th scope="col">first name</th>
                                <th scope="col">last name</th>
                                <th scope="col">identity card</th>
                                <th scope="col">birth date</th>
                                <th scope="col">driver licence date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <th scope="col"><img src="<?php echo e($client->avatar_path); ?>" alt="<?php echo e($client->avatar_path); ?>" width="60px" height="60px" style="border-radius: 50%;"></th>
                            <th scope="col"><?php echo e($client->first_name); ?></th>
                            <th scope="col"><?php echo e($client->last_name); ?></th>
                            <th scope="col"><?php echo e($client->identity_card); ?></th>
                            <th scope="col"><?php echo e($client->birth_date); ?></th>
                            <th scope="col"><?php echo e($client->driver_licence_date); ?></th>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/client_show.blade.php ENDPATH**/ ?>