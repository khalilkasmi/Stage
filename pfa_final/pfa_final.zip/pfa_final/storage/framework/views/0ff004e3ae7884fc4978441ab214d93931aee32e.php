
<div class="card-header"><?php echo e(__('Continue Registration')); ?></div>

<div class="card-body">

    <form method="POST" action="clients" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group row">
            <label for="first_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('First Name')); ?></label>

            <div class="col-md-6">
                <input id="first_name" type="text" class="form-control <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="first_name" value="<?php echo e(old('First Name')); ?>" required autocomplete="First Name" autofocus>

                <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="last_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label>

            <div class="col-md-6">
                <input id="last_name" type="text" class="form-control <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="last_name" value="<?php echo e(old('Last Name')); ?>" required autocomplete="Last Name" autofocus>

                <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="identity_card" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Identity Card')); ?></label>

            <div class="col-md-6">
                <input id="identity_card" type="text" class="form-control <?php if ($errors->has('identity_card')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_card'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="identity_card" value="<?php echo e(old('Identity Card')); ?>" required autocomplete="Identity Card" autofocus>

                <?php if ($errors->has('identity_card')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_card'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="birth_date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Birth Date')); ?></label>

            <div class="col-md-6">
                <input id="birth_date" type="date" class="form-control <?php if ($errors->has('birth_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birth_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="birth_date" value="<?php echo e(old('Birth Date')); ?>" required autocomplete="Birth Date" autofocus>

                <?php if ($errors->has('birth_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('birth_date'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>

        <div class="form-group row">
            <label for="driver_licence_date" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Driver Licence Date')); ?></label>

            <div class="col-md-6">
                <input id="driver_licence_date" type="date" class="form-control <?php if ($errors->has('driver_licence_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('driver_licence_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="driver_licence_date" value="<?php echo e(old('Driver Licence Date')); ?>" required autocomplete="Driver Licence Date" autofocus>

                <?php if ($errors->has('driver_licence_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('driver_licence_date'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
        </div>


        <div class="form-group">
        <label>Profile Picture</label>
        <input type="file" name="avatar_path" class="form-control <?php if ($errors->has('avatar_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar_path'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><br>
            <?php if ($errors->has('avatar_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('avatar_path'); ?>
            <span class="invalid-feedback " role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
            <div class="form-group">
        <label>Driver Licence</label>
        <input type="file" name="driver_licence_path" class="form-control <?php if ($errors->has('driver_licence_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('driver_licence_path'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><br>
                <?php if ($errors->has('driver_licence_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('driver_licence_path'); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
                <div class="form-group">
       <label>identity card</label>
        <input type="file" name="identity_card_path" class="form-control <?php if ($errors->has('identity_card_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_card_path'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    <?php if ($errors->has('identity_card_path')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('identity_card_path'); ?>
                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>



        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

        <div class="form-group row mb-0">
            <div class="col-md-6 offset-md-4">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
        </div>
    </form>
</div>

<?php /**PATH C:\xampp\htdocs\pfa_final\pfa_final\resources\views/Client/client_registration_completion.blade.php ENDPATH**/ ?>