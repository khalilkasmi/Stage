<p>Hi {{ $data['name'] }},</p>
<p>thans to contact us about ({{ $data['subject'] }}),</p>
<p>The message is: <br> {{ $data['message'] }}</p>
<p>Cordialement.</p>