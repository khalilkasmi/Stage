<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Chart Demo</div>

                <div class="panel-body">
                    <?php echo $chart->html(); ?>

                    <?php echo $chart_res->html(); ?>

                </div>

            </div>
        </div>
    </div>
</div>
<?php echo Charts::scripts(); ?>

<?php echo $chart->script(); ?>

<?php echo $chart_res->script(); ?>

<?php /**PATH C:\xampp\htdocs\pfa_final\admin\vendor\tcg\voyager\src/../resources/views/charts.blade.php ENDPATH**/ ?>